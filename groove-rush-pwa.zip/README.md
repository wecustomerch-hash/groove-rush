# Groove Rush PWA

Installable web app build. Works offline after the first load.

## Put it online (free)
Upload this folder to any static host that serves HTTPS, for example:
- GitHub Pages: push the folder to a repo, Settings > Pages > deploy from branch.
- Netlify Drop: https://app.netlify.com/drop (drag the folder in).

## Install on Android
Open the URL in Chrome, tap the three-dot menu, then "Install app" (or "Add to Home screen").
It launches fullscreen in landscape like a native app, with no browser bars.

## Turn it into a real APK / Play Store package
1. Go to https://www.pwabuilder.com and paste your hosted URL.
2. Choose "Package for stores" > Android. It generates a signed APK (for sideloading) and an AAB (for Play Store).
3. Download, install the APK on your phone, or upload the AAB to Play Console.

Note: the service worker only registers over http(s). Opening index.html directly from the file system still plays the game but will not install.
